package com.model;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import com.confiq.*;
public class RegisterModel {
	Dbconfiq db_object = new Dbconfiq();  // create an object for class Db_confiq
	PreparedStatement ptmt=null; // prepared statement is used to prepare sql statement in java for dynamicaly change the data
	public boolean Register(String name,String email,String phone,String password)
	{
		boolean result = false;
		try {
			ptmt=db_object.getconnection().prepareStatement("insert into tbl_user(vchr_fullname,vchr_email,vchr_phone,vchr_password)values(?,?,?,?)");
		    ptmt.setString(1, name); // the numbers indecate the index  of the ? marks
		    ptmt.setString(2, email);
		    ptmt.setString(3, phone);
		    ptmt.setString(4, password);
		    result = ptmt.execute();// this method is execute the statement as sql statement 
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return result;
		
	}

}
