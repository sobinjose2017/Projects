package com.model;
import java.sql.*;

import com.confiq.Dbconfiq;

public class LoginModel {
	Dbconfiq db_object = new Dbconfiq();  // create an object for class Db_confiq
	PreparedStatement ptmt=null; // prepared statement is used to prepare sql statement in java for dynamicaly change the data
    ResultSet rs;
	public ResultSet Login(String username,String password)
	{
		try {
			ptmt=db_object.getconnection().prepareStatement("select * from tbl_user where vchr_email=? and vchr_password=?");
			ptmt.setString(1, username); // the numbers indecate the index  of the ? marks
		    ptmt.setString(2, password);
		    rs=ptmt.executeQuery();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	    
	    
		
		return rs;
	}
}
