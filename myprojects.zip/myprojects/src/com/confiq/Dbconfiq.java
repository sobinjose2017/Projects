package com.confiq;

import java.sql.*;

public class Dbconfiq {

	public Connection con;
	public Connection getconnection()
	{
		try {
			//driver class regisetring
			Class.forName("com.mysql.jdbc.Driver");
		
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			//Connection manager Creation
			//con = DriverManager.getConnection("jdbc:mysql://hostname:port/dbname","username of database", "password of database");
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/ultsdemo","root", "");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return con;
	}
}
